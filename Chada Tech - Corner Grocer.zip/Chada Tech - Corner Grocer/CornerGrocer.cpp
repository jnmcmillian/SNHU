/*Julianne McMillian
Bill Chan
CS-210
Project Three: Corner Grocer
*/

#include <iostream>
#include <string>
#include <fstream>
#include <vector>

using namespace std;


/*Creation of histogram function before its use provides shorter code.
When called, it will replace frequency number with '*';
*/
void histogram(int count) {
    for (int i = 0; i < count; i++) {
        cout << "*";
    }
    cout << endl;
}

int main() {//Initialization of Variables
    string searchWord;
    int option;
    int count;


    //Opens CS-210 Project Three Input File, and reads from it whenever the user inputs an item.
    ifstream inputFile("CS210_Project_Three_Input_File.txt");

    if(!inputFile){
        cout << "Process Failed" << endl;

        return 1;
    }

    //Direct reading of the file, byte size set to char for accuracy
    string fileContent((istreambuf_iterator<char>(inputFile)), istreambuf_iterator<char>());

    //Closes CS-210 Project Three Input File
    inputFile.close();


    while(true) { //Menu Prompt, using a while function will allow the program to display the menu options after user exits certain options.
        cout << "\nWhat would you like to do?\n";
        cout << "1. Search for an item\n";//User searches an item from the list, and console will only display the number of times it appears in the list.
        cout << "2. Search for an item frequency\n";//User searches an item from the list, and the console will display the item searched along with its frequency.
        cout << "3. Display item Histogram\n";//User searches an item from the list, and the console will display item name, along with a history of frequency.
        cout << "4. EXIT THE PROGRAM\n" << endl;//User enters "4" to Exit the program.

        cin >> option; //Receive option number from the user


    if(option == 1){//User types in items they are looking for, separated by a space or newline, and the console will display numeric amount of appearances. FOR BEST READABILITY, ONLY SEARCH ONE ITEM PER LINE.
        cout << "Enter the words you are looking for, and press \" F \" for finished: \n";//Standard Entry for all menu options
        while(cin >> searchWord) {//The while function allows the user to input as many items as they want for as long as they want, as long as they do not quit the menu option.
            if ((searchWord == "F") || (searchWord == "f")) {//If the user enters "f" or "F", the option will quit and the program will display the menu screen again.
                break;
            }

            size_t count = 0;//Initializes count to 0
            size_t pos = fileContent.find(searchWord);
            while(pos != string::npos) {//While iterating through the Input file, everytime the system reads the searchWord, it will increment by 1
                count++;
                pos = fileContent.find(searchWord, pos + 1);
            }
            cout << count << endl << endl;//The numeric value will be outputted on the following line, after the searched word
        }
    }//END OF OPTION 1

    else if (option == 2){//Following prompt will generate when user enters "2" on menu display screen.
        cout << "Enter the words you are looking for, and press \" F \" for finished: \n";//Standard Entry for all menu options

        ofstream outFile("frequency.dat");//Creates a backup file named "frequency.dat" that will store searches made by the user

        if(outFile.is_open()) {//If the file is open, words searched by the user will be added to the file, along with their respective frequencies
        while(cin >> searchWord) {//Menu option will continue, as long as "f" or "F" isn't pressed
            if ((searchWord == "F") || (searchWord == "f")) {//If the user enters "f" or "F", the option will quit and the program will display the menu screen again.
                break;
            }

            size_t count = 0;//Initializes count to 0
            size_t pos = fileContent.find(searchWord);
            while(pos != string::npos) {//While iterating through the Input file, everytime the system reads the searchWord, it will increment by 1.
                count++;
                pos = fileContent.find(searchWord, pos + 1);
            }
            cout << searchWord << " " << count << endl << endl;//The searched item followed by the numeric value will be outputted on a new line, after the searched word.

            outFile << searchWord << " " << count << endl; /*Outputs displayed by the console will be copied onto the "frequency.dat" file
            in the order they were searched in.The "frequency.dat" will open and display items AFTER the program has been exited.
            */
        }
        outFile.close();//Closes "frequency.dat" file.
        }
    }

    else if (option == 3){//If user enters "3" option 3 ensue
        cout << "Enter the words you are looking for, and press \" F \" for finished: \n";//Standard Entry for all menu options
        while(cin >> searchWord) {//Menu option will continue, as long as "f" or "F" isn't pressed
            cout << endl;
            if ((searchWord == "F") || (searchWord == "f")) {//If the user enters "f" or "F", the option will quit and the program will display the menu screen again.
                break;
            }

            size_t count = 0;//Initializes count to 0
            size_t pos = fileContent.find(searchWord);
            while(pos != string::npos) {//While iterating through the Input file, everytime the system reads the searchWord, it will increment by 1.
                count++;
                pos = fileContent.find(searchWord, pos + 1);
            }
            cout << searchWord;//Console will output the searched word, which will then be followed by the histogram function
            histogram(count);//Converts the number from count to histograms with the '*' character (if count number is 3, histogram will output '***')
        }
    }

    else if (option == 4) {//If user enters "4" Program will exit, if user searched for items in menu option 2, frequency.dat will open.
        cout << "\nExiting...Goodbye.\n";
        break;
    }
    else {//If the user enters anything besides a number 1-4, the else option will occur, prompting the menu screen again.
        cout << "Invalid Option, Please try again.\n";
    }
    }

    return 0;
}